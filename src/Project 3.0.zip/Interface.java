import java.util.ArrayList;

public class Interface {
    public void addCompetition(){

    }
    public void getCompetitionInfo(){

    }
    public void showNotification(){

    }
    public void addParticipant(){

    }
    public void viewCompetitions(){

    }
    public void displayCompetitionList(){

    }
    public void selectedCompetition(String name){

    }
    public void displayCompetitionDetails(){

    }
    public void deleteCompetition(){

    }
    public void deleteSuccessful(){

    }
    public void sendEmail(){

    }
    public void displayTeams(ArrayList<Team> teamList){

    }
    public void sendEmail(Team team){

    }
    public void browseCompetition(){

    }
    public void displayCompWebsite(String url){

    }
}
