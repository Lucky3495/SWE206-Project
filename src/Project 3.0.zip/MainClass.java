public class MainClass {
    private static CompetitionList comps;
    public static void main(String[] args) {
        comps = new CompetitionList();
    }
    public void viewCompetitionsSelected(){

    }
    public void competitionSelected(String name){

    }
    public void deleteCompetitionSelected(){

    }
    public void sendEmail(){

    }
    public void addStudent(String id, String name, String major, IndieComp comp){

    }
    public void addTeam(String name, Competition competition){

    }
}
